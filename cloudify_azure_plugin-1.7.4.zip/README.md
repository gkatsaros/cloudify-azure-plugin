# Microsoft Azure plugin for Cloudify

## Docs

See [Cloudify Azure Plugin docs](https://docs.cloudify.co/4.3.0/working_with/official_plugins/azure/).

## Changelog

See [changelog](https://github.com/cloudify-incubator/cloudify-azure-plugin/blob/master/changelog.txt).
