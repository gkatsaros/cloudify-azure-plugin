.. _auth_oauth2:

.. autoclass:: cloudify_azure.auth.oauth2.AzureCredentials

.. automodule:: cloudify_azure.auth.oauth2
    :members:
    :inherited-members:
    :exclude-members: AzureCredentials
