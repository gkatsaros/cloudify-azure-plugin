.. _connection:

.. automodule:: cloudify_azure.connection
    :members:
    :inherited-members:
