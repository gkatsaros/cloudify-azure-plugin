.. _resources_base:

.. automodule:: cloudify_azure.resources.base
    :members:
    :inherited-members:
