.. _resources_compute_virtualmachine:

.. automodule:: cloudify_azure.resources.compute.virtualmachine
    :members:
    :inherited-members:
