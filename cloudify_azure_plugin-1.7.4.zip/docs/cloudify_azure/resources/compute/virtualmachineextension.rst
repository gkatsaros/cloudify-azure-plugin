.. _resources_compute_virtualmachineextension:

.. automodule:: cloudify_azure.resources.compute.virtualmachineextension
    :members:
    :inherited-members:
