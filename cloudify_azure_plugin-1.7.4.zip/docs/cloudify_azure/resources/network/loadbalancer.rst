.. _resources_network_loadbalancer:

.. automodule:: cloudify_azure.resources.network.loadbalancer
    :members:
    :inherited-members:
