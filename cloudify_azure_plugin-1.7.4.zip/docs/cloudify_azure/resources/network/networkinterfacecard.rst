.. _resources_network_networkinterfacecard:

.. automodule:: cloudify_azure.resources.network.networkinterfacecard
    :members:
    :inherited-members:
