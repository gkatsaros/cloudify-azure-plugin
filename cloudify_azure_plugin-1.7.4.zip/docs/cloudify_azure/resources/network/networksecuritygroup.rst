.. _resources_network_networksecuritygroup:

.. automodule:: cloudify_azure.resources.network.networksecuritygroup
    :members:
    :inherited-members:
