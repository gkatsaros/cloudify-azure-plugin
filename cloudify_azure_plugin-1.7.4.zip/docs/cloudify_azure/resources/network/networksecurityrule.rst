.. _resources_network_networksecurityrule:

.. automodule:: cloudify_azure.resources.network.networksecurityrule
    :members:
    :inherited-members:
