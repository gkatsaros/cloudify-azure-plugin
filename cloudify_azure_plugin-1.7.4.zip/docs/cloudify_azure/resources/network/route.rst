.. _resources_network_route:

.. automodule:: cloudify_azure.resources.network.route
    :members:
    :inherited-members:
