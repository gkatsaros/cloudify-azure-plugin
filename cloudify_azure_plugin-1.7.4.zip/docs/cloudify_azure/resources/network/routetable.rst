.. _resources_network_routetable:

.. automodule:: cloudify_azure.resources.network.routetable
    :members:
    :inherited-members:
