.. _resources_resourcegroup:

.. automodule:: cloudify_azure.resources.resourcegroup
    :members:
    :inherited-members:
