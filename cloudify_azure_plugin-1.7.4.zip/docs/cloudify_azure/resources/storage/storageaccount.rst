.. _resources_storage_storageaccount:

.. automodule:: cloudify_azure.resources.storage.storageaccount
    :members:
    :inherited-members:
