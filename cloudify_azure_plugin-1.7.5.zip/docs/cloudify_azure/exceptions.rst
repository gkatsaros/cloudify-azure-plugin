.. _exceptions:

.. automodule:: cloudify_azure.exceptions
    :members:
    :inherited-members:
