.. _resources_compute_availabilityset:

.. automodule:: cloudify_azure.resources.compute.availabilityset
    :members:
    :inherited-members:
