.. _resources_network_ipconfiguration:

.. automodule:: cloudify_azure.resources.network.ipconfiguration
    :members:
    :inherited-members:
