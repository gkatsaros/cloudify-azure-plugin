.. _resources_network_publicipaddress:

.. automodule:: cloudify_azure.resources.network.publicipaddress
    :members:
    :inherited-members:
