.. _resources_network_subnet:

.. automodule:: cloudify_azure.resources.network.subnet
    :members:
    :inherited-members:
