.. _resources_network_virtualnetwork:

.. automodule:: cloudify_azure.resources.network.virtualnetwork
    :members:
    :inherited-members:
