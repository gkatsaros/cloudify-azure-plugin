.. _utils:

.. automodule:: cloudify_azure.utils
    :members:
    :inherited-members:
